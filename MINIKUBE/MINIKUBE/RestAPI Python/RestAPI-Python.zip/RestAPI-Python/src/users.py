users= [
    {"name": "user1"},
    {"name": "user2"},
    {"name": "user3"}
]